interface Collection {
    imageUrl: string;
    prompt: string;
    timestamp: string;
}