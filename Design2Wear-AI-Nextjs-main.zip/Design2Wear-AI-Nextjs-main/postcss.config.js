module.exports = {
  theme: {    
  },
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
